ARROWRADAR MOBILE — ИСХОДНИКИ ДЛЯ СБОРКИ APK ЧЕРЕЗ GITHUB ACTIONS

Этот архив содержит Android-проект. Его НЕ нужно распаковывать на компьютере для сборки.
Загрузите сам ZIP в корень репозитория GitHub с именем: arrowradar-android-source.zip
Затем создайте файл .github/workflows/build-arrowradar-apk.yml и вставьте YAML из инструкции, которую вы получили вместе с архивом.

После Commit changes откройте вкладку Actions, запустите workflow Build ArrowRadar Android APK.
После успешной сборки откройте запуск workflow и скачайте Artifact ArrowRadar-Mobile-test-APK. Внутри будет app-debug.apk.

Внимание: APK — тестовая отладочная сборка, не релиз для Google Play. Для Google Play потребуется отдельная release-сборка и подпись ключом.
Погодные данные и спутниковые тайлы требуют доступных сетевых источников. Сборка APK сама по себе не гарантирует доступность погоды без VPN.
