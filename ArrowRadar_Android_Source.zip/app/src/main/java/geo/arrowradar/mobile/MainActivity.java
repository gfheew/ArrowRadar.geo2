package geo.arrowradar.mobile;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MainActivity extends Activity {
    private static final String HOST = "gfheew.github.io";
    private static final String BASE = "/ArrowRadar.geo2/";
    private static final String LOCAL_ORIGIN = "https://appassets.androidplatform.net/";
    private static final String FEED_URL = "https://" + HOST + BASE + "weather-feed.json";
    // Older forecasts must never be passed to the app as fresh weather.
    private static final long FEED_MAX_AGE_MS = 65L * 60_000L;
    private static final int MAX_FEED_BYTES = 8_000_000;

    private WebView web;
    // UI/WebView interception must never wait for network operations.
    private final ExecutorService feedExecutor = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final AtomicBoolean feedLoading = new AtomicBoolean(false);
    private volatile byte[] lastFeed;
    private volatile long lastFeedTimestamp = 0L;
    private volatile long lastAttemptTime = 0L;
    private boolean inForeground;
    private final Runnable feedTick = new Runnable() {
        @Override public void run() {
            if (!inForeground) return;
            fetchFeedAsync(false);
            ui.postDelayed(this, 60_000L);
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(6,21,34));
        getWindow().setNavigationBarColor(Color.rgb(6,21,34));

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(5,11,19));
        // Android 15+ draws apps edge-to-edge. Reserve room for the system bars.
        if (Build.VERSION.SDK_INT >= 35) {
            web.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(0, bars.top, 0, bars.bottom);
                return insets;
            });
        }
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setSupportZoom(false); // Map has its own gestures.
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (!"https".equalsIgnoreCase(u.getScheme())) return null;
                String path = u.getPath();
                if (path == null) return null;
                // The bundled page has its own stable, local HTTPS origin.
                // The weather feed is returned from memory; the WebView thread never waits on a network request.
                boolean fromApp = "appassets.androidplatform.net".equalsIgnoreCase(u.getHost());
                boolean fromSite = HOST.equalsIgnoreCase(u.getHost());
                if (fromApp && "/weather-feed.json".equals(path)) return weatherResponse();
                if (fromSite && (BASE + "weather-feed.json").equals(path)) return weatherResponse();
                return null;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                if (!req.isForMainFrame()) return false;
                Uri u = req.getUrl();
                if ("https".equalsIgnoreCase(u.getScheme())
                    && "appassets.androidplatform.net".equalsIgnoreCase(u.getHost())) return false;
                if ("http".equalsIgnoreCase(u.getScheme()) || "https".equalsIgnoreCase(u.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                }
                return true;
            }
        });
        // Show the interface even if DNS, GitHub Pages, or all weather services are unreachable.
        // Local HTTPS base URL keeps localStorage available for the first-run tutorial.
        try (InputStream asset = getAssets().open("www/index.html")) {
            String html = new String(readLimited(asset), StandardCharsets.UTF_8);
            web.loadDataWithBaseURL(LOCAL_ORIGIN, html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            web.loadDataWithBaseURL(LOCAL_ORIGIN,
                "<html lang='ru'><meta charset='utf-8'><body style='background:#071522;color:white;font:18px sans-serif;padding:20px'>"
                + "Не удалось открыть интерфейс ArrowRadar. Переустановите приложение.</body></html>",
                "text/html", "UTF-8", null);
        }
        // Fetch a fresh forecast separately. Never block the WebView resource thread.
        fetchFeedAsync(true);
    }

    private static WebResourceResponse resource(String mime, InputStream data) {
        Map<String, String> headers = new HashMap<>();
        headers.put("Cache-Control", "no-store");
        headers.put("Access-Control-Allow-Origin", "*");
        return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers, data);
    }
    private static WebResourceResponse errorResponse(String reason) {
        Map<String,String> headers = new HashMap<>();
        headers.put("Cache-Control", "no-store");
        return new WebResourceResponse("text/plain", "UTF-8", 503,
                "Service Unavailable", headers,
                new ByteArrayInputStream(reason.getBytes(StandardCharsets.UTF_8)));
    }

    private WebResourceResponse weatherResponse() {
        byte[] snapshot = lastFeed; // Immutable byte[] snapshot, read without network or locks.
        long age = System.currentTimeMillis() - lastFeedTimestamp;
        if (snapshot == null || age < -120_000L || age >= FEED_MAX_AGE_MS) {
            return errorResponse("No verified fresh forecast available");
        }
        return resource("application/json", new ByteArrayInputStream(snapshot));
    }

    private void fetchFeedAsync(boolean loadDisk) {
        final long now = System.currentTimeMillis();
        if (!loadDisk && now - lastAttemptTime < 55_000L) return;
        if (!feedLoading.compareAndSet(false, true)) return;
        lastAttemptTime = now;
        feedExecutor.execute(() -> {
            try {
                if (loadDisk) {
                    // File IO runs in the background, even on the very first launch.
                    try (FileInputStream input = new FileInputStream(new File(getFilesDir(), "forecast.json"))) {
                        byte[] stored = readLimited(input);
                        publishIfFresh(stored);
                    } catch (Exception ignored) { }
                }
                try {
                    byte[] body = downloadFeed();
                    if (isFresh(body, System.currentTimeMillis())) {
                        publishIfFresh(body);
                        try (FileOutputStream out = new FileOutputStream(new File(getFilesDir(), "forecast.json"))) {
                            out.write(body);
                        }
                    }
                } catch (Exception ignored) { /* No verified feed: don't pretend it's safe. */ }
            } finally { feedLoading.set(false); }
        });
    }

    private static byte[] readLimited(InputStream input) throws Exception {
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int n;
            while ((n = input.read(buffer)) != -1) {
                if (out.size() + n > MAX_FEED_BYTES) throw new IllegalStateException("Forecast too large");
                out.write(buffer, 0, n);
            }
            return out.toByteArray();
        }
    }

    private void publishIfFresh(byte[] body) {
        long now = System.currentTimeMillis();
        if (!isFresh(body, now)) return;
        long timestamp;
        try {
            JSONObject j = new JSONObject(new String(body, StandardCharsets.UTF_8));
            timestamp = OffsetDateTime.parse(j.getString("generated_at")).toInstant().toEpochMilli();
        } catch (Exception e) { return; }
        lastFeed = body;
        lastFeedTimestamp = timestamp;
        ui.post(() -> {
            if (web != null && inForeground) {
                web.evaluateJavascript("window.dispatchEvent(new Event('arrowradar:feed-ready'));", null);
            }
        });
    }

    private static byte[] downloadFeed() throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(FEED_URL).openConnection();
        conn.setConnectTimeout(4_000);
        conn.setReadTimeout(5_000);
        conn.setRequestProperty("Accept", "application/json");
        conn.setUseCaches(false);
        try {
            if (conn.getResponseCode() != 200) throw new IllegalStateException("Feed HTTP " + conn.getResponseCode());
            try (InputStream stream = conn.getInputStream()) { return readLimited(stream); }
        } finally { conn.disconnect(); }
    }

    private static boolean isFresh(byte[] body, long now) {
        if (body == null || body.length < 50 || body.length > MAX_FEED_BYTES) return false;
        try {
            JSONObject json = new JSONObject(new String(body, StandardCharsets.UTF_8));
            if (!json.has("generated_at") || json.optJSONArray("cities") == null
                    || json.optJSONArray("cities").length() < 35) return false;
            long created = OffsetDateTime.parse(json.getString("generated_at")).toInstant().toEpochMilli();
            long age = now - created;
            return age >= -120_000L && age < FEED_MAX_AGE_MS;
        } catch (Exception e) { return false; }
    }

    @Override protected void onResume() {
        super.onResume();
        inForeground = true;
        if (web != null) web.onResume();
        ui.removeCallbacks(feedTick);
        ui.post(feedTick);
    }
    @Override protected void onPause() {
        inForeground = false;
        ui.removeCallbacks(feedTick);
        if (web != null) web.onPause();
        super.onPause();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
    @Override public void onDestroy() {
        inForeground = false;
        ui.removeCallbacks(feedTick);
        feedExecutor.shutdownNow();
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
