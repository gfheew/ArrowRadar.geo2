plugins { id("com.android.application") }

android {
    namespace = "geo.arrowradar.mobile"
    compileSdk = 36
    defaultConfig {
        applicationId = "geo.arrowradar.mobile"
        minSdk = 26
        targetSdk = 36
        versionCode = 3
        versionName = "0.3-beginner-test"
    }
    buildTypes {
        getByName("release") { isMinifyEnabled = false }
        getByName("debug") { isDebuggable = true }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging { resources.excludes.add("META-INF/*") }
}
